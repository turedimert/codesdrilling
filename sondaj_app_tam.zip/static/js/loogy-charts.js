/**
 * LOOGY Grafik Modülü
 * LOOGY markalı renk şeması ve görsel kimlik ile geliştirilmiş grafikler
 */

// LOOGY Renk Paleti
const LOOGY_COLORS = {
  primary: '#ff6600',     // Ana turuncu renk
  secondary: '#343a40',   // Koyu gri
  accent: '#17a2b8',      // Mavi aksan
  success: '#28a745',     // Yeşil
  danger: '#dc3545',      // Kırmızı
  warning: '#ffc107',     // Sarı
  light: '#f8f9fa',       // Açık gri
  dark: '#343a40',        // Koyu gri
  // Renk geçişleri için paletler
  oranges: ['#ffab66', '#ff8c33', '#ff6600', '#cc5200', '#993d00'],
  grays: ['#e9ecef', '#dee2e6', '#ced4da', '#adb5bd', '#6c757d', '#495057', '#343a40', '#212529'],
  blues: ['#7fdbff', '#39ccff', '#00b8ff', '#0099cc', '#007a99']
};

// Standart grafik ayarları
const LOOGY_CHART_CONFIG = {
  font: {
    family: 'Arial, sans-serif',
    size: 12,
    color: LOOGY_COLORS.grays[6]
  },
  titleFont: {
    family: 'Arial, sans-serif',
    size: 16,
    color: LOOGY_COLORS.grays[7],
    weight: 'bold'
  },
  gridColor: LOOGY_COLORS.grays[2],
  paperBgColor: LOOGY_COLORS.light,
  plotBgColor: 'rgba(255, 255, 255, 0.95)',
  watermark: {
    text: 'LOOGY',
    opacity: 0.04,
    font: {
      family: 'Arial, sans-serif',
      size: 60,
      color: LOOGY_COLORS.primary
    }
  }
};

/**
 * SPT Grafiği Oluşturur
 * @param {string} elementId - Grafiğin ekleneceği HTML element ID'si
 * @param {Array} depths - Derinlik değerleri
 * @param {Array} n30Values - N30 değerleri
 * @param {string} title - Grafik başlığı
 */
function createSptChart(elementId, depths, n30Values, title = 'SPT Grafiği') {
  // Veri hazırlama
  const trace = {
    x: n30Values,
    y: depths,
    type: 'scatter',
    mode: 'lines+markers',
    name: 'N30 Değerleri',
    line: {
      color: LOOGY_COLORS.primary,
      width: 2
    },
    marker: {
      color: LOOGY_COLORS.primary,
      size: 8,
      line: {
        color: LOOGY_COLORS.light,
        width: 1
      }
    }
  };
  
  // SPT değerlendirme bölgeleri
  const zeminDurumu = [
    {
      n30Range: [0, 4],
      name: 'Çok Gevşek',
      fillColor: 'rgba(220, 53, 69, 0.2)'  // danger renk
    },
    {
      n30Range: [4, 10],
      name: 'Gevşek',
      fillColor: 'rgba(255, 193, 7, 0.2)'  // warning renk
    },
    {
      n30Range: [10, 30],
      name: 'Orta Sıkı',
      fillColor: 'rgba(255, 102, 0, 0.2)'  // primary renk
    },
    {
      n30Range: [30, 50],
      name: 'Sıkı',
      fillColor: 'rgba(40, 167, 69, 0.2)'  // success renk
    },
    {
      n30Range: [50, 100],
      name: 'Çok Sıkı',
      fillColor: 'rgba(23, 162, 184, 0.2)'  // accent renk
    }
  ];
  
  // Sıkılık bölgeleri için dikdörtgenler oluştur
  const shapes = zeminDurumu.map(durum => {
    return {
      type: 'rect',
      x0: durum.n30Range[0],
      x1: durum.n30Range[1],
      y0: Math.min(...depths),
      y1: Math.max(...depths),
      fillcolor: durum.fillColor,
      line: {
        width: 0
      },
      layer: 'below'
    };
  });
  
  // SPT değerlendirme çizgileri
  const sptLines = zeminDurumu.map(durum => {
    return {
      x: [durum.n30Range[1], durum.n30Range[1]],
      y: [Math.min(...depths), Math.max(...depths)],
      type: 'scatter',
      mode: 'lines',
      line: {
        color: 'rgba(0, 0, 0, 0.1)',
        width: 1,
        dash: 'dot'
      },
      showlegend: false,
      hoverinfo: 'none'
    };
  });
  
  // SPT değerlendirme etiketleri
  const annotations = zeminDurumu.map(durum => {
    const xPos = (durum.n30Range[0] + durum.n30Range[1]) / 2;
    return {
      x: xPos,
      y: Math.min(...depths) - 0.5,
      text: durum.name,
      showarrow: false,
      font: {
        family: 'Arial, sans-serif',
        size: 9,
        color: LOOGY_COLORS.grays[6]
      }
    };
  });
  
  // Grafik düzeni
  const layout = {
    title: {
      text: title,
      font: LOOGY_CHART_CONFIG.titleFont
    },
    xaxis: {
      title: 'N30 Değeri',
      range: [0, Math.max(50, Math.max(...n30Values) * 1.1)],
      gridcolor: LOOGY_CHART_CONFIG.gridColor,
      linecolor: LOOGY_CHART_CONFIG.gridColor,
      mirror: true,
      showgrid: true
    },
    yaxis: {
      title: 'Derinlik (m)',
      autorange: 'reversed', // Derinlik yukarıdan aşağı artsın
      gridcolor: LOOGY_CHART_CONFIG.gridColor,
      linecolor: LOOGY_CHART_CONFIG.gridColor,
      mirror: true,
      showgrid: true
    },
    paper_bgcolor: LOOGY_CHART_CONFIG.paperBgColor,
    plot_bgcolor: LOOGY_CHART_CONFIG.plotBgColor,
    shapes: shapes,
    annotations: annotations,
    hovermode: 'closest',
    font: LOOGY_CHART_CONFIG.font,
    margin: { t: 60, r: 30, b: 60, l: 60 },
    // LOOGY Su damgası
    images: [{
      source: '/static/img/loogy-logo.svg',
      x: 0.5,
      y: 0.5,
      xref: 'paper',
      yref: 'paper',
      sizex: 0.5,
      sizey: 0.5,
      opacity: 0.05,
      layer: 'below'
    }]
  };
  
  // Veri kümesi
  const data = [trace, ...sptLines];
  
  // Grafik oluştur
  Plotly.newPlot(elementId, data, layout, {
    responsive: true,
    displayModeBar: true,
    modeBarButtonsToRemove: ['lasso2d', 'select2d']
  });
}

/**
 * Zemin Profili Grafiği Oluşturur
 * @param {string} elementId - Grafiğin ekleneceği HTML element ID'si
 * @param {Array} depths - Derinlik değerleri
 * @param {Array} soilTypes - Zemin türleri
 * @param {string} title - Grafik başlığı
 */
function createSoilProfileChart(elementId, depths, soilTypes, title = 'Zemin Profili') {
  // Zemin türleri için renk kodları
  const soilColors = {
    'kum': LOOGY_COLORS.oranges[1],
    'kil': LOOGY_COLORS.grays[4],
    'silt': LOOGY_COLORS.grays[2],
    'çakıl': LOOGY_COLORS.oranges[3],
    'kayaç': LOOGY_COLORS.grays[6],
    'organik': LOOGY_COLORS.success,
    'dolgu': LOOGY_COLORS.warning
  };
  
  // Default renk
  const defaultColor = LOOGY_COLORS.primary;
  
  // Her zemin katmanı için dikdörtgen şekiller oluşturma
  const shapes = [];
  
  for (let i = 0; i < depths.length - 1; i++) {
    // Zemin tipini kontrol et ve renk ata
    let fillColor = defaultColor;
    
    // Basit bir zemin tipi kontrolü
    for (const [soilType, color] of Object.entries(soilColors)) {
      if (soilTypes[i].toLowerCase().includes(soilType)) {
        fillColor = color;
        break;
      }
    }
    
    // Katman dikdörtgeni ekle
    shapes.push({
      type: 'rect',
      x0: 0,
      x1: 1,
      y0: depths[i],
      y1: depths[i + 1],
      fillcolor: fillColor,
      line: {
        width: 1,
        color: 'white'
      },
      layer: 'below'
    });
  }
  
  // Katman etiketleri
  const annotations = [];
  
  for (let i = 0; i < depths.length - 1; i++) {
    const midDepth = (depths[i] + depths[i + 1]) / 2;
    
    annotations.push({
      x: 0.5,
      y: midDepth,
      text: soilTypes[i],
      showarrow: false,
      font: {
        family: 'Arial, sans-serif',
        size: 10,
        color: 'white'
      }
    });
    
    // Derinlik işaretleyicileri
    annotations.push({
      x: 0,
      y: depths[i],
      text: `${depths[i]} m`,
      showarrow: false,
      xanchor: 'left',
      font: {
        family: 'Arial, sans-serif',
        size: 9,
        color: LOOGY_COLORS.grays[7]
      }
    });
  }
  
  // Son derinlik işaretleyicisi
  annotations.push({
    x: 0,
    y: depths[depths.length - 1],
    text: `${depths[depths.length - 1]} m`,
    showarrow: false,
    xanchor: 'left',
    font: {
      family: 'Arial, sans-serif',
      size: 9,
      color: LOOGY_COLORS.grays[7]
    }
  });
  
  // Grafik düzeni
  const layout = {
    title: {
      text: title,
      font: LOOGY_CHART_CONFIG.titleFont
    },
    xaxis: {
      showticklabels: false,
      showgrid: false,
      zeroline: false,
      fixedrange: true
    },
    yaxis: {
      title: 'Derinlik (m)',
      autorange: 'reversed',
      showgrid: true,
      gridcolor: LOOGY_CHART_CONFIG.gridColor,
      zeroline: false
    },
    shapes: shapes,
    annotations: annotations,
    paper_bgcolor: LOOGY_CHART_CONFIG.paperBgColor,
    plot_bgcolor: 'rgba(0,0,0,0)',
    showlegend: false,
    font: LOOGY_CHART_CONFIG.font,
    margin: { t: 60, r: 30, b: 60, l: 60 },
    // LOOGY Su damgası
    images: [{
      source: '/static/img/loogy-logo.svg',
      x: 0.5,
      y: 0.5,
      xref: 'paper',
      yref: 'paper',
      sizex: 0.3,
      sizey: 0.3,
      opacity: 0.05,
      layer: 'below'
    }]
  };
  
  // Boş bir iz - sadece layout göstermek için
  const data = [{
    x: [0, 1],
    y: [0, 0],
    type: 'scatter',
    mode: 'markers',
    marker: { opacity: 0 },
    showlegend: false,
    hoverinfo: 'none'
  }];
  
  // Grafik oluştur
  Plotly.newPlot(elementId, data, layout, {
    responsive: true,
    displayModeBar: true,
    modeBarButtonsToRemove: ['lasso2d', 'select2d', 'zoomIn2d', 'zoomOut2d', 'autoScale2d']
  });
}

/**
 * Çoklu Parametre Karşılaştırma Grafiği
 * @param {string} elementId - Grafiğin ekleneceği HTML element ID'si
 * @param {Array} depths - Derinlik değerleri
 * @param {Object} parameters - Parametre adı ve değerleri
 * @param {string} title - Grafik başlığı
 */
function createMultiParameterChart(elementId, depths, parameters, title = 'Zemin Parametreleri') {
  // Tüm izleri toplama
  const traces = [];
  
  // Renk indeksi
  let colorIndex = 0;
  const colors = [
    LOOGY_COLORS.primary,
    LOOGY_COLORS.accent,
    LOOGY_COLORS.success,
    LOOGY_COLORS.warning,
    LOOGY_COLORS.danger
  ];
  
  // Her parametre için bir çizgi oluştur
  for (const [paramName, values] of Object.entries(parameters)) {
    traces.push({
      x: values,
      y: depths,
      type: 'scatter',
      mode: 'lines+markers',
      name: paramName,
      line: {
        color: colors[colorIndex % colors.length],
        width: 2
      },
      marker: {
        color: colors[colorIndex % colors.length],
        size: 6
      }
    });
    
    colorIndex++;
  }
  
  // Grafik düzeni
  const layout = {
    title: {
      text: title,
      font: LOOGY_CHART_CONFIG.titleFont
    },
    xaxis: {
      title: 'Değer',
      gridcolor: LOOGY_CHART_CONFIG.gridColor,
      zeroline: true,
      zerolinecolor: LOOGY_CHART_CONFIG.gridColor
    },
    yaxis: {
      title: 'Derinlik (m)',
      autorange: 'reversed',
      gridcolor: LOOGY_CHART_CONFIG.gridColor,
      zeroline: false
    },
    paper_bgcolor: LOOGY_CHART_CONFIG.paperBgColor,
    plot_bgcolor: LOOGY_CHART_CONFIG.plotBgColor,
    hovermode: 'closest',
    font: LOOGY_CHART_CONFIG.font,
    margin: { t: 60, r: 30, b: 60, l: 60 },
    legend: {
      x: 1,
      y: 1,
      xanchor: 'right',
      bordercolor: LOOGY_CHART_CONFIG.gridColor,
      borderwidth: 1
    },
    // LOOGY Su damgası
    images: [{
      source: '/static/img/loogy-logo.svg',
      x: 0.5,
      y: 0.5,
      xref: 'paper',
      yref: 'paper',
      sizex: 0.4,
      sizey: 0.4,
      opacity: 0.05,
      layer: 'below'
    }]
  };
  
  // Grafik oluştur
  Plotly.newPlot(elementId, traces, layout, {
    responsive: true,
    displayModeBar: true,
    modeBarButtonsToRemove: ['lasso2d', 'select2d']
  });
}

/**
 * Metraj Özeti Pasta Grafiği
 * @param {string} elementId - Grafiğin ekleneceği HTML element ID'si
 * @param {Object} soilDistribution - Zemin dağılımı (tür:miktar)
 * @param {string} title - Grafik başlığı
 */
function createSoilDistributionChart(elementId, soilDistribution, title = 'Zemin Dağılımı') {
  // Veri hazırlama
  const labels = Object.keys(soilDistribution);
  const values = Object.values(soilDistribution);
  
  // Zemin türleri için renk kodları (createSoilProfileChart ile aynı)
  const soilColors = {
    'kum': LOOGY_COLORS.oranges[1],
    'kil': LOOGY_COLORS.grays[4],
    'silt': LOOGY_COLORS.grays[2],
    'çakıl': LOOGY_COLORS.oranges[3],
    'kayaç': LOOGY_COLORS.grays[6],
    'organik': LOOGY_COLORS.success,
    'dolgu': LOOGY_COLORS.warning
  };
  
  // Her etiket için renk atama
  const colors = labels.map(label => {
    // Basit bir zemin tipi kontrolü
    for (const [soilType, color] of Object.entries(soilColors)) {
      if (label.toLowerCase().includes(soilType)) {
        return color;
      }
    }
    return LOOGY_COLORS.primary; // Varsayılan renk
  });
  
  // Pasta grafiği izleri
  const trace = {
    type: 'pie',
    labels: labels,
    values: values,
    textinfo: 'label+percent',
    textposition: 'inside',
    insidetextfont: {
      color: 'white'
    },
    hoverinfo: 'label+value+percent',
    marker: {
      colors: colors,
      line: {
        color: 'white',
        width: 2
      }
    }
  };
  
  // Grafik düzeni
  const layout = {
    title: {
      text: title,
      font: LOOGY_CHART_CONFIG.titleFont
    },
    paper_bgcolor: LOOGY_CHART_CONFIG.paperBgColor,
    font: LOOGY_CHART_CONFIG.font,
    legend: {
      orientation: 'h',
      y: -0.2
    },
    margin: { t: 60, b: 60 },
    // LOOGY Su damgası
    images: [{
      source: '/static/img/loogy-logo.svg',
      x: 0.5,
      y: 0.5,
      xref: 'paper',
      yref: 'paper',
      sizex: 0.3,
      sizey: 0.3,
      opacity: 0.05,
      layer: 'below'
    }]
  };
  
  // Grafik oluştur
  Plotly.newPlot(elementId, [trace], layout, {
    responsive: true,
    displayModeBar: false
  });
}

/**
 * Zaman Serisi Grafiği (Proje İlerleme, Ölçüm Zamanlaması)
 * @param {string} elementId - Grafiğin ekleneceği HTML element ID'si
 * @param {Array} dates - Tarih değerleri
 * @param {Array} values - Ölçüm/ilerleme değerleri
 * @param {string} title - Grafik başlığı
 */
function createTimeSeriesChart(elementId, dates, values, title = 'Proje İlerlemesi') {
  // Veri hazırlama
  const trace = {
    x: dates,
    y: values,
    type: 'scatter',
    mode: 'lines+markers',
    name: 'İlerleme',
    line: {
      color: LOOGY_COLORS.primary,
      width: 2
    },
    marker: {
      color: LOOGY_COLORS.primary,
      size: 8,
      line: {
        color: LOOGY_COLORS.light,
        width: 1
      }
    },
    fill: 'tozeroy',
    fillcolor: `rgba(${parseInt(LOOGY_COLORS.primary.slice(1, 3), 16)}, ${parseInt(LOOGY_COLORS.primary.slice(3, 5), 16)}, ${parseInt(LOOGY_COLORS.primary.slice(5, 7), 16)}, 0.2)`
  };
  
  // Grafik düzeni
  const layout = {
    title: {
      text: title,
      font: LOOGY_CHART_CONFIG.titleFont
    },
    xaxis: {
      title: 'Tarih',
      type: 'date',
      gridcolor: LOOGY_CHART_CONFIG.gridColor,
      zeroline: false
    },
    yaxis: {
      title: 'Değer',
      gridcolor: LOOGY_CHART_CONFIG.gridColor,
      zeroline: true,
      zerolinecolor: LOOGY_CHART_CONFIG.gridColor
    },
    paper_bgcolor: LOOGY_CHART_CONFIG.paperBgColor,
    plot_bgcolor: LOOGY_CHART_CONFIG.plotBgColor,
    hovermode: 'closest',
    font: LOOGY_CHART_CONFIG.font,
    margin: { t: 60, r: 30, b: 60, l: 60 },
    // LOOGY Su damgası
    images: [{
      source: '/static/img/loogy-logo.svg',
      x: 0.5,
      y: 0.5,
      xref: 'paper',
      yref: 'paper',
      sizex: 0.4,
      sizey: 0.4,
      opacity: 0.05,
      layer: 'below'
    }]
  };
  
  // Grafik oluştur
  Plotly.newPlot(elementId, [trace], layout, {
    responsive: true,
    displayModeBar: true,
    modeBarButtonsToRemove: ['lasso2d', 'select2d']
  });
}

// Modülü dışa aktar
window.LoogyCharts = {
  createSptChart,
  createSoilProfileChart,
  createMultiParameterChart,
  createSoilDistributionChart,
  createTimeSeriesChart,
  LOOGY_COLORS
};