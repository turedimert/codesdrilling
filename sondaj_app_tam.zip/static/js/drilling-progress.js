/**
 * Sondaj İlerleme Göstergeleri JavaScript Dosyası
 * 
 * Sondaj işlemlerinde ilerlemeyi görselleştirmek için kullanılır.
 */

// İlerleme çubukları ve animasyonlar için temel sınıf
class DrillingProgress {
    constructor(containerId, options = {}) {
        this.container = document.getElementById(containerId);
        if (!this.container) {
            console.error(`Container with ID "${containerId}" not found.`);
            return;
        }

        this.options = Object.assign({
            height: 400,
            width: 200,
            animationDuration: 1500,
            labelPosition: 'bottom',
            colors: {
                primary: '#3498db',
                secondary: '#f1c40f',
                background: '#ecf0f1',
                text: '#2c3e50'
            }
        }, options);

        this.initialize();
    }

    initialize() {
        this.container.style.position = 'relative';
        this.container.style.width = `${this.options.width}px`;
        this.container.style.height = `${this.options.height}px`;
        this.container.style.margin = '0 auto';
        this.container.classList.add('drilling-progress-container');
    }

    // Yüzde bazlı ilerleme animasyonu
    animateProgress(value, maxValue, callback) {
        const percentage = (value / maxValue) * 100;
        return new Promise((resolve) => {
            const element = document.createElement('div');
            element.className = 'progress-bar';
            element.style.position = 'absolute';
            element.style.bottom = '0';
            element.style.width = '100%';
            element.style.backgroundColor = this.options.colors.background;
            element.style.height = '100%';
            element.style.transition = `transform ${this.options.animationDuration}ms ease-out`;
            element.style.transformOrigin = 'bottom';
            element.style.transform = 'scaleY(0)';
            
            const fillElement = document.createElement('div');
            fillElement.className = 'progress-fill';
            fillElement.style.position = 'absolute';
            fillElement.style.bottom = '0';
            fillElement.style.width = '100%';
            fillElement.style.backgroundColor = this.options.colors.primary;
            fillElement.style.height = `${percentage}%`;
            fillElement.style.transition = `height ${this.options.animationDuration}ms ease-out`;
            fillElement.style.transformOrigin = 'bottom';
            fillElement.style.transform = 'scaleY(0)';
            
            element.appendChild(fillElement);
            this.container.appendChild(element);
            
            setTimeout(() => {
                element.style.transform = 'scaleY(1)';
                fillElement.style.transform = 'scaleY(1)';
                
                setTimeout(() => {
                    if (callback) callback(element, percentage);
                    resolve({ element, percentage });
                }, this.options.animationDuration);
            }, 50);
        });
    }

    // Etiket ekle
    addLabel(text, position = 'bottom') {
        const label = document.createElement('div');
        label.className = 'progress-label';
        label.textContent = text;
        label.style.position = 'absolute';
        label.style.textAlign = 'center';
        label.style.width = '100%';
        label.style.color = this.options.colors.text;
        label.style.fontWeight = 'bold';
        
        if (position === 'top') {
            label.style.top = '-25px';
        } else if (position === 'bottom') {
            label.style.bottom = '-25px';
        }
        
        this.container.appendChild(label);
        return label;
    }

    // Temizle
    clear() {
        while (this.container.firstChild) {
            this.container.removeChild(this.container.firstChild);
        }
    }
}

// Sondaj derinliği ilerleme göstergesi
class DrillingDepthProgress extends DrillingProgress {
    constructor(containerId, options) {
        super(containerId, options);
        this.depthMarkers = [];
    }

    // Derinlik ölçeklendirilmiş görsel
    renderDepthVisualization(currentDepth, maxDepth, depthMarkers = []) {
        this.clear();
        this.depthMarkers = depthMarkers;
        
        // Ana sondaj çubuğu
        const drillPipe = document.createElement('div');
        drillPipe.className = 'drill-pipe';
        drillPipe.style.position = 'absolute';
        drillPipe.style.left = '50%';
        drillPipe.style.marginLeft = '-10px';
        drillPipe.style.width = '20px';
        drillPipe.style.height = `${this.options.height}px`;
        drillPipe.style.backgroundColor = this.options.colors.background;
        drillPipe.style.borderRadius = '10px';
        this.container.appendChild(drillPipe);
        
        // Derinlik işaretçileri
        this.depthMarkers.forEach(marker => {
            const depth = marker.depth;
            const percentage = (depth / maxDepth) * 100;
            const position = (percentage / 100) * this.options.height;
            
            const markerElement = document.createElement('div');
            markerElement.className = 'depth-marker';
            markerElement.style.position = 'absolute';
            markerElement.style.left = '0';
            markerElement.style.top = `${position}px`;
            markerElement.style.width = '100%';
            markerElement.style.height = '2px';
            markerElement.style.backgroundColor = marker.color || this.options.colors.secondary;
            
            const label = document.createElement('div');
            label.className = 'marker-label';
            label.textContent = `${depth}m - ${marker.label || ''}`;
            label.style.position = 'absolute';
            label.style.left = '110%';
            label.style.top = '-10px';
            label.style.fontSize = '12px';
            label.style.color = this.options.colors.text;
            
            markerElement.appendChild(label);
            this.container.appendChild(markerElement);
        });
        
        // Sondaj ucu
        const drillBit = document.createElement('div');
        drillBit.className = 'drill-bit';
        drillBit.style.position = 'absolute';
        drillBit.style.left = '50%';
        drillBit.style.marginLeft = '-15px';
        drillBit.style.width = '30px';
        drillBit.style.height = '30px';
        drillBit.style.backgroundColor = this.options.colors.primary;
        drillBit.style.borderRadius = '50%';
        drillBit.style.top = '0px';
        drillBit.style.transition = `top ${this.options.animationDuration}ms ease-out`;
        this.container.appendChild(drillBit);
        
        // Ana etiket
        const depthLabel = this.addLabel(`0m / ${maxDepth}m`);
        
        // Animasyon
        setTimeout(() => {
            const percentage = (currentDepth / maxDepth) * 100;
            const position = (percentage / 100) * this.options.height;
            drillBit.style.top = `${position}px`;
            
            // İlerleme çubuğu
            const progress = document.createElement('div');
            progress.className = 'drill-progress';
            progress.style.position = 'absolute';
            progress.style.left = '50%';
            progress.style.marginLeft = '-10px';
            progress.style.width = '20px';
            progress.style.height = `${position}px`;
            progress.style.backgroundColor = this.options.colors.primary;
            progress.style.borderRadius = '10px';
            progress.style.top = '0';
            progress.style.transformOrigin = 'top';
            progress.style.transform = 'scaleY(0)';
            progress.style.transition = `transform ${this.options.animationDuration}ms ease-out`;
            
            this.container.insertBefore(progress, drillBit);
            
            setTimeout(() => {
                progress.style.transform = 'scaleY(1)';
                depthLabel.textContent = `${currentDepth}m / ${maxDepth}m`;
            }, 50);
            
        }, 500);
    }
}

// SPT Değeri ilerleme göstergesi
class SPTValueProgress extends DrillingProgress {
    constructor(containerId, options) {
        super(containerId, options);
    }

    // SPT değerlerini gösterir
    renderSPTValues(values, labels, maxValue = 50) {
        this.clear();
        
        const barWidth = (this.options.width - 20) / values.length;
        
        values.forEach((value, index) => {
            const barContainer = document.createElement('div');
            barContainer.className = 'spt-bar-container';
            barContainer.style.position = 'absolute';
            barContainer.style.bottom = '0';
            barContainer.style.left = `${10 + (index * barWidth)}px`;
            barContainer.style.width = `${barWidth - 10}px`;
            barContainer.style.height = '100%';
            this.container.appendChild(barContainer);
            
            const percentage = (value / maxValue) * 100;
            
            this.animateProgress(value, maxValue, (element, percentage) => {
                const fillElement = element.querySelector('.progress-fill');
                fillElement.style.backgroundColor = this.getColorBySPTValue(value);
                
                const valueLabel = document.createElement('div');
                valueLabel.className = 'value-label';
                valueLabel.textContent = value;
                valueLabel.style.position = 'absolute';
                valueLabel.style.top = `${100 - percentage - 5}%`;
                valueLabel.style.width = '100%';
                valueLabel.style.textAlign = 'center';
                valueLabel.style.fontWeight = 'bold';
                element.appendChild(valueLabel);
                
                if (labels && labels[index]) {
                    const depthLabel = document.createElement('div');
                    depthLabel.className = 'depth-label';
                    depthLabel.textContent = labels[index];
                    depthLabel.style.position = 'absolute';
                    depthLabel.style.bottom = '-25px';
                    depthLabel.style.width = '100%';
                    depthLabel.style.textAlign = 'center';
                    depthLabel.style.fontSize = '12px';
                    element.appendChild(depthLabel);
                }
            }).then(result => {
                barContainer.appendChild(result.element);
            });
        });
        
        // Açıklama ekleme
        const legend = document.createElement('div');
        legend.className = 'spt-legend';
        legend.style.position = 'relative';
        legend.style.marginTop = '40px';
        legend.style.display = 'flex';
        legend.style.justifyContent = 'space-around';
        legend.style.padding = '10px';
        legend.style.borderTop = '1px solid #ddd';
        
        const categories = [
            { label: 'Çok Gevşek (<4)', color: '#e74c3c' },
            { label: 'Gevşek (4-10)', color: '#f39c12' },
            { label: 'Orta Sıkı (10-30)', color: '#2ecc71' },
            { label: 'Sıkı (30-50)', color: '#3498db' },
            { label: 'Çok Sıkı (>50)', color: '#8e44ad' }
        ];
        
        categories.forEach(category => {
            const item = document.createElement('div');
            item.style.display = 'flex';
            item.style.alignItems = 'center';
            item.style.marginRight = '10px';
            
            const colorBox = document.createElement('div');
            colorBox.style.width = '15px';
            colorBox.style.height = '15px';
            colorBox.style.backgroundColor = category.color;
            colorBox.style.marginRight = '5px';
            
            const text = document.createElement('span');
            text.textContent = category.label;
            text.style.fontSize = '12px';
            
            item.appendChild(colorBox);
            item.appendChild(text);
            legend.appendChild(item);
        });
        
        const legendContainer = document.createElement('div');
        legendContainer.style.width = '100%';
        legendContainer.style.position = 'absolute';
        legendContainer.style.bottom = '-80px';
        legendContainer.appendChild(legend);
        
        this.container.parentNode.appendChild(legendContainer);
    }
    
    // SPT değerine göre renk belirle
    getColorBySPTValue(value) {
        if (value < 4) return '#e74c3c'; // Çok Gevşek
        if (value < 10) return '#f39c12'; // Gevşek
        if (value < 30) return '#2ecc71'; // Orta Sıkı
        if (value < 50) return '#3498db'; // Sıkı
        return '#8e44ad'; // Çok Sıkı
    }
}

// Zemin profili görselleştirici
class SoilProfileVisualizer extends DrillingProgress {
    constructor(containerId, options) {
        super(containerId, options);
    }
    
    // Zemin profili gösterir
    renderSoilProfile(layers) {
        this.clear();
        
        const totalDepth = layers.reduce((sum, layer) => sum + layer.thickness, 0);
        let currentTop = 0;
        
        const renderDelay = this.options.animationDuration / layers.length;
        
        // Her katmanı sırayla render et
        layers.forEach((layer, index) => {
            setTimeout(() => {
                const percentage = (layer.thickness / totalDepth) * 100;
                const height = (percentage / 100) * this.options.height;
                
                const layerElement = document.createElement('div');
                layerElement.className = 'soil-layer';
                layerElement.style.position = 'absolute';
                layerElement.style.width = '100%';
                layerElement.style.height = `${height}px`;
                layerElement.style.top = `${currentTop}px`;
                layerElement.style.backgroundColor = layer.color || this.getSoilColor(layer.type);
                layerElement.style.borderTop = index > 0 ? '2px dashed #333' : 'none';
                layerElement.style.opacity = '0';
                layerElement.style.transition = 'opacity 500ms ease-in-out';
                
                const label = document.createElement('div');
                label.className = 'layer-label';
                label.textContent = layer.type;
                label.style.position = 'absolute';
                label.style.right = '10px';
                label.style.top = '50%';
                label.style.transform = 'translateY(-50%)';
                label.style.color = this.getContrastColor(layer.color || this.getSoilColor(layer.type));
                label.style.fontWeight = 'bold';
                label.style.fontSize = '14px';
                label.style.textShadow = '1px 1px 1px rgba(0,0,0,0.3)';
                
                const depthLabel = document.createElement('div');
                depthLabel.className = 'depth-label';
                depthLabel.textContent = `${layer.depth}m`;
                depthLabel.style.position = 'absolute';
                depthLabel.style.left = '10px';
                depthLabel.style.top = '5px';
                depthLabel.style.fontSize = '12px';
                depthLabel.style.color = this.getContrastColor(layer.color || this.getSoilColor(layer.type));
                
                layerElement.appendChild(label);
                layerElement.appendChild(depthLabel);
                this.container.appendChild(layerElement);
                
                setTimeout(() => {
                    layerElement.style.opacity = '1';
                }, 50);
                
                currentTop += height;
            }, index * renderDelay);
        });
        
        // Derinlik ölçeği ekleme
        setTimeout(() => {
            const scaleContainer = document.createElement('div');
            scaleContainer.className = 'depth-scale';
            scaleContainer.style.position = 'absolute';
            scaleContainer.style.left = '-40px';
            scaleContainer.style.top = '0';
            scaleContainer.style.height = '100%';
            scaleContainer.style.width = '30px';
            
            // Her metre için bir işaretçi ekle
            for (let i = 0; i <= totalDepth; i++) {
                const position = (i / totalDepth) * this.options.height;
                
                const marker = document.createElement('div');
                marker.className = 'depth-marker';
                marker.style.position = 'absolute';
                marker.style.top = `${position}px`;
                marker.style.width = '10px';
                marker.style.height = '1px';
                marker.style.backgroundColor = '#333';
                marker.style.right = '0';
                
                const label = document.createElement('div');
                label.textContent = `${i}m`;
                label.style.position = 'absolute';
                label.style.right = '15px';
                label.style.top = '-8px';
                label.style.fontSize = '10px';
                
                marker.appendChild(label);
                scaleContainer.appendChild(marker);
            }
            
            this.container.appendChild(scaleContainer);
        }, layers.length * renderDelay + 500);
    }
    
    // Zemin tipine göre renk
    getSoilColor(soilType) {
        const colorMap = {
            'Kil': '#8B4513',
            'Silt': '#CD853F',
            'Kum': '#F4A460',
            'Çakıl': '#D2B48C',
            'Kaya': '#A9A9A9',
            'Organik': '#2E8B57',
            'Dolgu': '#696969'
        };
        
        for (const type in colorMap) {
            if (soilType.toLowerCase().includes(type.toLowerCase())) {
                return colorMap[type];
            }
        }
        
        return '#DEB887'; // Varsayılan toprak rengi
    }
    
    // Kontrast renk hesapla (açık arka planlar için koyu metin, koyu arka planlar için açık metin)
    getContrastColor(hexColor) {
        // Hex rengi RGB'ye dönüştür
        const r = parseInt(hexColor.substr(1, 2), 16);
        const g = parseInt(hexColor.substr(3, 2), 16);
        const b = parseInt(hexColor.substr(5, 2), 16);
        
        // Parlaklığı hesapla
        const brightness = (r * 299 + g * 587 + b * 114) / 1000;
        
        // Eşik değerine göre beyaz veya siyah dön
        return brightness > 128 ? '#000000' : '#FFFFFF';
    }
}