document.addEventListener('DOMContentLoaded', function() {
  // Silme modalları sorununu çözme - tüm silme formları için
  const fixDeleteModals = () => {
    // Modal açıldığında Bootstrap tarafından eklenen backdrop tıklama olaylarını kaldır
    document.addEventListener('show.bs.modal', function (event) {
      const modal = event.target;
      
      if (modal.querySelector('form') && 
          (modal.id.includes('delete') || modal.id.includes('sil'))) {
        
        // Modal backdrop'ı tıklama ile kapatmayı devre dışı bırak
        const modalInstance = bootstrap.Modal.getInstance(modal);
        if (modalInstance) {
          modal.dataset.backdrop = 'static';
          modal.dataset.keyboard = 'false';
        }
      }
    });
  };
  
  // Hemen çağır
  fixDeleteModals();
  
  // Sayfa yükleme animasyonu
  const pageLoader = document.querySelector('.page-loader');
  if (pageLoader) {
    // Sayfanın yüklendiğini biraz geciktirerek göster (gerçek yüklenme hızını göstermek için)
    setTimeout(() => {
      pageLoader.classList.add('loaded');
      // Tamamen kaybolması için ek süre
      setTimeout(() => {
        pageLoader.style.display = 'none';
      }, 500);
    }, 800);
  }

  // Bootstrap bileşenlerini etkinleştir
  var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
  var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
    return new bootstrap.Tooltip(tooltipTriggerEl);
  });
  
  var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
  var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
    return new bootstrap.Popover(popoverTriggerEl);
  });
  
  // Sayfa geçişlerinde animasyon
  document.querySelectorAll('.animated-content').forEach(function(element) {
    element.classList.add('fade-in');
  });
  
  // Flash mesajlarını animasyonlu olarak göster ve gizle
  const flashMessages = document.querySelectorAll('.alert-dismissible');
  flashMessages.forEach(function(alert) {
    // Önce görünmez yap, sonra animasyonla göster
    alert.style.opacity = '0';
    alert.style.transform = 'translateY(-20px)';
    
    setTimeout(function() {
      alert.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
      alert.style.opacity = '1';
      alert.style.transform = 'translateY(0)';
    }, 100);
    
    // Belirli bir süre sonra animasyonla gizle
    setTimeout(function() {
      alert.style.opacity = '0';
      alert.style.transform = 'translateY(-20px)';
      
      setTimeout(function() {
        var bsAlert = new bootstrap.Alert(alert);
        bsAlert.close();
      }, 500);
    }, 5000);
  });
  
  // Form doğrulama ve animasyon
  const forms = document.querySelectorAll('.needs-validation');
  
  Array.prototype.slice.call(forms).forEach(function (form) {
    form.addEventListener('submit', function (event) {
      if (!form.checkValidity()) {
        event.preventDefault();
        event.stopPropagation();
        
        // Hata oluştuğunda formu titreşim animasyonu ile göster
        form.classList.add('shake-animation');
        setTimeout(function() {
          form.classList.remove('shake-animation');
        }, 820); // Animasyon süresi + biraz bekle
      }
      
      form.classList.add('was-validated');
    }, false);
  });
  
  // Card hover animasyonlarını zenginleştir
  document.querySelectorAll('.card').forEach(function(card) {
    card.addEventListener('mouseenter', function() {
      this.querySelectorAll('.card-hover-reveal').forEach(function(element) {
        element.style.opacity = '1';
        element.style.transform = 'translateY(0)';
      });
    });
    
    card.addEventListener('mouseleave', function() {
      this.querySelectorAll('.card-hover-reveal').forEach(function(element) {
        element.style.opacity = '0';
        element.style.transform = 'translateY(10px)';
      });
    });
  });
  
  // Mobil menu açılış animasyonu
  const navbarToggler = document.querySelector('.navbar-toggler');
  if (navbarToggler) {
    navbarToggler.addEventListener('click', function() {
      document.querySelector('.navbar-collapse').classList.toggle('slide-in-right');
    });
  }
  
  // Tablo satırlarına hover animasyonu ekle
  document.querySelectorAll('.table-hover tbody tr').forEach(function(row) {
    row.addEventListener('mouseenter', function() {
      this.classList.add('table-hover-active');
    });
    
    row.addEventListener('mouseleave', function() {
      this.classList.remove('table-hover-active');
    });
  });
  
  // Geliştirilmiş confirm dialog
  window.confirmDelete = function(message, callback) {
    // Basit onay iletişim kutusu oluşturma
    const confirmModal = document.createElement('div');
    confirmModal.className = 'modal fade';
    confirmModal.id = 'confirmModal';
    confirmModal.setAttribute('tabindex', '-1');
    confirmModal.setAttribute('aria-hidden', 'true');
    
    confirmModal.innerHTML = `
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content animate__animated animate__fadeInUp animate__faster">
          <div class="modal-header bg-light">
            <h5 class="modal-title"><i class="mdi mdi-alert-circle text-warning me-2"></i>Onay</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Kapat"></button>
          </div>
          <div class="modal-body">
            ${message}
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
            <button type="button" class="btn btn-danger" id="confirmBtn">
              <i class="mdi mdi-delete me-1"></i>Sil
            </button>
          </div>
        </div>
      </div>
    `;
    
    document.body.appendChild(confirmModal);
    
    const modal = new bootstrap.Modal(confirmModal);
    modal.show();
    
    document.getElementById('confirmBtn').addEventListener('click', function() {
      modal.hide();
      
      // Modal kapatıldıktan sonra kaldır
      confirmModal.addEventListener('hidden.bs.modal', function() {
        document.body.removeChild(confirmModal);
        callback();
      });
    });
    
    confirmModal.addEventListener('hidden.bs.modal', function() {
      if (document.body.contains(confirmModal)) {
        document.body.removeChild(confirmModal);
      }
    });
  };
  
  // Tarih inputlarını geliştir
  const dateInputs = document.querySelectorAll('input[type="date"]');
  dateInputs.forEach(function(input) {
    // Tarih inputu için özel stil sınıfı ekle
    input.classList.add('date-input-styled');
    
    input.addEventListener('change', function() {
      if (this.value) {
        const date = new Date(this.value);
        const formattedDate = date.toLocaleDateString('tr-TR', {
          year: 'numeric',
          month: 'long',
          day: 'numeric'
        });
        
        this.setAttribute('title', formattedDate);
        
        // Değişiklikleri görsel olarak belirt
        this.classList.add('date-changed');
        setTimeout(() => {
          this.classList.remove('date-changed');
        }, 1000);
      }
    });
  });
  
  // Sayısal input formatını geliştir
  const numberInputs = document.querySelectorAll('input[type="number"]');
  numberInputs.forEach(function(input) {
    input.classList.add('number-input-styled');
    
    input.addEventListener('focus', function() {
      this.classList.add('input-focus-effect');
    });
    
    input.addEventListener('blur', function() {
      this.classList.remove('input-focus-effect');
      
      if (this.value) {
        const num = parseFloat(this.value);
        if (!isNaN(num)) {
          this.value = num.toFixed(2);
          
          // Değişiklikleri görsel olarak belirt
          this.classList.add('number-changed');
          setTimeout(() => {
            this.classList.remove('number-changed');
          }, 1000);
        }
      }
    });
  });
  
  // Özel sondaj derinliği görselleştirmesi
  const updateSondajProgress = () => {
    const sondajDerinligiInputs = document.querySelectorAll('input[name="sondaj_derinligi"]');
    sondajDerinligiInputs.forEach(input => {
      const value = parseFloat(input.value) || 0;
      
      // Eski progress elementini kaldır
      const parent = input.parentElement;
      const oldProgress = parent.querySelector('.sondaj-progress');
      if (oldProgress) {
        parent.removeChild(oldProgress);
      }
      
      // Yeni progress elementini oluştur
      if (value > 0) {
        const progressEl = document.createElement('div');
        progressEl.className = 'sondaj-progress';
        progressEl.innerHTML = `
          <div class="progress mt-2" style="height: 8px;">
            <div class="progress-bar bg-primary" role="progressbar" 
                 style="width: ${Math.min(100, value * 5)}%;" 
                 aria-valuenow="${value}" aria-valuemin="0" aria-valuemax="20"></div>
          </div>
          <small class="text-muted mt-1 d-block text-end">${value} metre</small>
        `;
        parent.appendChild(progressEl);
      }
    });
  };
  
  // Sondaj derinliği değiştiğinde görselleştirmeyi güncelle
  document.addEventListener('input', function(e) {
    if (e.target.name === 'sondaj_derinligi') {
      updateSondajProgress();
    }
  });
  
  // Sayfa yüklendiğinde de çalıştır
  updateSondajProgress();
  
  // Sayfadaki tabloları güzelleştir
  const enhanceTables = () => {
    document.querySelectorAll('table').forEach(table => {
      if (!table.classList.contains('table-enhanced')) {
        table.classList.add('table-enhanced');
        
        // Tabloya kapsayıcı ekle (eğer yoksa)
        if (!table.parentElement.classList.contains('table-responsive')) {
          const wrapper = document.createElement('div');
          wrapper.className = 'table-responsive shadow-sm rounded';
          table.parentNode.insertBefore(wrapper, table);
          wrapper.appendChild(table);
        }
      }
    });
  };
  
  enhanceTables();
  
  // Sayfa scroll animasyonları
  const scrollAnimations = () => {
    const elements = document.querySelectorAll('.scroll-animate');
    
    elements.forEach(element => {
      const position = element.getBoundingClientRect();
      
      // Eleman görünür alanda mı?
      if(position.top < window.innerHeight && position.bottom >= 0) {
        element.classList.add('scroll-animated');
      }
    });
  };
  
  window.addEventListener('scroll', scrollAnimations);
  scrollAnimations(); // Sayfa yüklendiğinde başlangıç kontrolü
});

// Sondaj uygulaması için özel JS
function createDrillingSampleAnimation() {
  // Sondaj örneklerine animasyon uygulayan fonksiyon
  const sampleElements = document.querySelectorAll('.sample-item');
  
  sampleElements.forEach((element, index) => {
    // Gecikme ekleyerek sıralı animasyon etkisi oluştur
    setTimeout(() => {
      element.classList.add('sample-animated');
    }, index * 150);
  });
}

// Projelere arama filtresi ekleme
function filterProjects(searchTerm) {
  const projectItems = document.querySelectorAll('.project-card');
  
  projectItems.forEach(item => {
    const projectName = item.querySelector('.project-name').textContent.toLowerCase();
    
    if (projectName.includes(searchTerm.toLowerCase())) {
      item.style.display = 'block';
      // Eşleşen metni vurgula
      const nameElement = item.querySelector('.project-name');
      const regex = new RegExp(`(${searchTerm})`, 'gi');
      nameElement.innerHTML = nameElement.textContent.replace(regex, '<span class="highlight">$1</span>');
    } else {
      item.style.display = 'none';
    }
  });
}