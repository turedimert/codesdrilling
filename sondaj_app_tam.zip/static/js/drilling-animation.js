/**
 * LOOGY Sondaj Animasyon Modülü
 * Sondaj verilerini görselleştirmek için gelişmiş animasyonlu gösterimler
 */

// Ana sondaj animasyonunu oluşturan fonksiyon
function createDrillingAnimation(containerId, depth, samples = []) {
  // Konteyner elementini bul
  const container = document.getElementById(containerId);
  if (!container) return;
  
  // Varolan içeriği temizle
  container.innerHTML = '';
  container.classList.add('drilling-visualization');
  
  // Ölçek hesapla (maks. 300px yükseklik)
  const maxHeight = 300;
  const scale = depth > 0 ? Math.min(maxHeight / depth, 30) : 30;  // Her metre için maks 30px
  const visualHeight = Math.min(depth * scale, maxHeight);
  
  // Temel konteyner
  const drillVisual = document.createElement('div');
  drillVisual.className = 'drill-visual';
  drillVisual.style.height = `${visualHeight}px`;
  
  // Zemin katmanları
  const layers = document.createElement('div');
  layers.className = 'soil-layers';
  
  // Metre işaretleri ve derinlik göstergeleri
  const markers = document.createElement('div');
  markers.className = 'depth-markers';
  
  // Her bir metre için işaret ekle
  for (let i = 0; i <= depth; i++) {
    if (i % 1.5 === 0 || i === depth) {  // Her 1.5 metrede bir veya son derinlikte
      const marker = document.createElement('div');
      marker.className = 'depth-marker';
      marker.style.bottom = `${(i / depth) * 100}%`;
      
      const label = document.createElement('span');
      label.className = 'depth-label';
      label.textContent = `${i.toFixed(1)}m`;
      marker.appendChild(label);
      
      markers.appendChild(marker);
    }
  }
  
  // Sondaj çubuğu animasyonu
  const drill = document.createElement('div');
  drill.className = 'drill-rod';
  
  // Sondaj ucu
  const drillBit = document.createElement('div');
  drillBit.className = 'drill-bit';
  drillBit.innerHTML = '<i class="mdi mdi-chevron-down"></i>';
  drill.appendChild(drillBit);
  
  // Logo
  const logo = document.createElement('div');
  logo.className = 'drill-logo';
  logo.innerHTML = `<img src="/static/img/loogy-logo.svg" alt="LOOGY" width="30" height="30">`;
  drill.appendChild(logo);
  
  // Örnekleri yerleştir
  if (samples && samples.length > 0) {
    samples.forEach(sample => {
      const sampleMarker = document.createElement('div');
      sampleMarker.className = `sample-marker sample-type-${sample.type}`;
      sampleMarker.style.bottom = `${(sample.depth / depth) * 100}%`;
      sampleMarker.setAttribute('title', `${sample.name || 'Örnek'}: ${sample.depth}m`);
      sampleMarker.innerHTML = `<span class="sample-icon"><i class="mdi ${getSampleIcon(sample.type)}"></i></span>`;
      
      // Tıklama ile bilgi göster
      sampleMarker.addEventListener('click', () => {
        showSampleInfo(sample);
      });
      
      layers.appendChild(sampleMarker);
    });
    
    // Örnek noktaları arasına katman çizgileri ekle
    addSoilLayers(layers, samples, depth);
  }
  
  // Animasyon
  animateDrilling(drill, depth, scale);
  
  // Tüm elementleri bir araya getir
  drillVisual.appendChild(layers);
  drillVisual.appendChild(markers);
  drillVisual.appendChild(drill);
  
  // Bilgi paneli
  const infoPanel = document.createElement('div');
  infoPanel.className = 'info-panel';
  infoPanel.innerHTML = `
    <div class="total-depth">
      <span class="info-label">Toplam Derinlik:</span>
      <span class="info-value">${depth}m</span>
    </div>
    <div class="samples-count">
      <span class="info-label">Örnek Sayısı:</span>
      <span class="info-value">${samples.length}</span>
    </div>
  `;
  
  // Oluşturulan elementleri ana konteynere ekle
  container.appendChild(drillVisual);
  container.appendChild(infoPanel);
  
  // Etkileşim için tooltip initialize et
  initializeTooltips();
}

// Örnek türüne göre ikon döndür
function getSampleIcon(type) {
  switch(type?.toLowerCase()) {
    case 'spt':
      return 'mdi-hammer-wrench';
    case 'ud':
      return 'mdi-test-tube';
    case 'karot':
      return 'mdi-cylinder';
    default:
      return 'mdi-arrow-down-circle';
  }
}

// Katmanları oluştur
function addSoilLayers(container, samples, totalDepth) {
  if (!samples || samples.length === 0) return;
  
  // Örnek derinliklerine göre sırala
  const sortedSamples = [...samples].sort((a, b) => a.depth - b.depth);
  
  // İlk örneğin üstündeki boşluk için katman
  const topLayer = document.createElement('div');
  topLayer.className = 'soil-layer';
  topLayer.style.bottom = `${100}%`;
  topLayer.style.height = `${(sortedSamples[0].depth / totalDepth) * 100}%`;
  topLayer.style.backgroundColor = getRandomSoilColor(0);
  container.appendChild(topLayer);
  
  // Örnekler arası katmanlar
  for (let i = 0; i < sortedSamples.length - 1; i++) {
    const layerHeight = sortedSamples[i+1].depth - sortedSamples[i].depth;
    const layerBottom = sortedSamples[i].depth;
    
    const layer = document.createElement('div');
    layer.className = 'soil-layer';
    layer.style.bottom = `${(layerBottom / totalDepth) * 100}%`;
    layer.style.height = `${(layerHeight / totalDepth) * 100}%`;
    layer.style.backgroundColor = getRandomSoilColor(i + 1);
    container.appendChild(layer);
  }
  
  // Son örneğin altındaki boşluk için katman
  const lastSample = sortedSamples[sortedSamples.length - 1];
  if (lastSample.depth < totalDepth) {
    const bottomLayerHeight = totalDepth - lastSample.depth;
    const bottomLayer = document.createElement('div');
    bottomLayer.className = 'soil-layer';
    bottomLayer.style.bottom = `${(lastSample.depth / totalDepth) * 100}%`;
    bottomLayer.style.height = `${(bottomLayerHeight / totalDepth) * 100}%`;
    bottomLayer.style.backgroundColor = getRandomSoilColor(sortedSamples.length);
    container.appendChild(bottomLayer);
  }
}

// Zemin rengi oluştur
function getRandomSoilColor(index) {
  // LOOGY renk paletini kullan
  const palette = [
    'rgba(247, 231, 206, 0.8)',   // açık kum
    'rgba(191, 155, 120, 0.8)',   // kum
    'rgba(130, 108, 79, 0.8)',    // koyu kum
    'rgba(102, 84, 60, 0.8)',     // kil
    'rgba(89, 74, 56, 0.8)',      // koyu kil
    'rgba(150, 150, 150, 0.8)',   // silt
    'rgba(120, 120, 120, 0.8)',   // gri
    'rgba(180, 180, 180, 0.8)',   // açık gri
  ];
  
  return palette[index % palette.length];
}

// Sondaj animasyonu
function animateDrilling(drillElement, depth, scale) {
  // Başlangıç konumu (en üstte)
  drillElement.style.height = '60px';
  drillElement.style.bottom = '100%';
  
  // Sondaj animasyonu (aşağı iniyor)
  setTimeout(() => {
    drillElement.style.transition = 'all 2s cubic-bezier(0.34, 1.56, 0.64, 1)';
    drillElement.style.height = `${depth * scale + 60}px`;
    drillElement.style.bottom = '0%';
  }, 500);
}

// Örnek bilgilerini göster
function showSampleInfo(sample) {
  const infoModal = document.getElementById('sampleInfoModal');
  if (!infoModal) {
    // Modal yok, oluştur
    const modal = document.createElement('div');
    modal.className = 'modal fade';
    modal.id = 'sampleInfoModal';
    modal.setAttribute('tabindex', '-1');
    modal.setAttribute('aria-hidden', 'true');
    
    modal.innerHTML = `
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
          <div class="modal-header bg-primary text-white">
            <h5 class="modal-title">Örnek Detayı</h5>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Kapat"></button>
          </div>
          <div class="modal-body sample-info-content">
            <div class="text-center mb-3">
              <img src="/static/img/loogy-logo.svg" alt="LOOGY" width="40" height="40" class="me-2">
              <h6 class="sample-name">${sample.name || 'Örnek'}</h6>
            </div>
            <div class="row">
              <div class="col-6">
                <p><strong>Derinlik:</strong> ${sample.depth}m</p>
                <p><strong>Tür:</strong> ${sample.type || 'Belirtilmemiş'}</p>
              </div>
              <div class="col-6">
                <p><strong>SPT:</strong> ${sample.spt || '-'}</p>
                <p><strong>RQD:</strong> ${sample.rqd || '-'}</p>
              </div>
            </div>
            <div class="sample-description mt-3">
              <p><strong>Tanımlama:</strong> ${sample.description || 'Bilgi girilmemiş'}</p>
            </div>
          </div>
        </div>
      </div>
    `;
    
    document.body.appendChild(modal);
    const modalObj = new bootstrap.Modal(modal);
    modalObj.show();
  } else {
    // Modal zaten var, içeriği güncelle ve göster
    const sampleName = infoModal.querySelector('.sample-name');
    if (sampleName) sampleName.textContent = sample.name || 'Örnek';
    
    const modalObj = bootstrap.Modal.getInstance(infoModal) || new bootstrap.Modal(infoModal);
    modalObj.show();
  }
}

// Tooltipleri başlat
function initializeTooltips() {
  const tooltipTriggerList = [].slice.call(document.querySelectorAll('[title]'));
  tooltipTriggerList.map(function (tooltipTriggerEl) {
    return new bootstrap.Tooltip(tooltipTriggerEl);
  });
}

// Dokümana yükleme işlevi
document.addEventListener('DOMContentLoaded', function() {
  // Sayfada .drilling-container elementleri var mı kontrol et
  const drillingContainers = document.querySelectorAll('.drilling-container');
  
  drillingContainers.forEach(container => {
    // Element veri özelliklerinden değerleri al
    const depth = parseFloat(container.dataset.depth || 0);
    const samplesJson = container.dataset.samples || '[]';
    
    try {
      const samples = JSON.parse(samplesJson);
      createDrillingAnimation(container.id, depth, samples);
    } catch (e) {
      console.error('Sondaj verileri yüklenirken hata oluştu:', e);
      container.innerHTML = '<div class="alert alert-danger">Sondaj verileri yüklenemedi</div>';
    }
  });
});